const express =require('express')
const router = express.Router()
const Post = require('../models/Post')
const verifyToken = require('../verifyToken')

// POST (Create data) - requires authentication
router.post('/', verifyToken, async(req,res)=>{
    //console.log("User from Token:", req.user)
    const postData = new Post({
        title:req.body.title,
        description:req.body.description,
        likes:req.body.likes,
        createdBy:req.user._id  // createdBy?
    })
    // try to insert...
    try{
        const postToSave = await postData.save()
        res.send(postToSave)
    }catch(err){
        res.status(400).send({message:err})
    }
})

// GET 1 (Read all) - publicly available
router.get('/', async(req,res) =>{
    try{
        const getPosts = await Post.find().populate('createdBy', 'name').limit(10)
        res.send(getPosts)
    }catch(err){
        res.status(400).send({message:err})
    }   
})

// GET 2 (Read by ID) - publicly available
router.get('/:id', async(req,res) =>{
    try{
        const getPostById = await Post.findById(req.params.id)
        res.send(getPostById)
    }catch(err){
        res.status(400).send({message:err})
    }
})

// PATCH (Update) - only the post creator can update
router.patch('/:id', verifyToken, async(req,res) =>{
    try{
        const updatePostById = await Post.updateOne(
            {_id:req.params.id},
            {$set:{
                title:req.body.title,
                description:req.body.description,
                likes:req.body.likes,
                createdBy:req.user._id
                }
            })
        res.send(updatePostById)
    }catch(err){
        res.send({message:err})
    }
})

// DELETE (Delete) - only the post creator can delete
router.delete('/:id', verifyToken, async(req,res)=>{
    try{
        const deletePostById = await Post.deleteOne({_id:req.params.id})
        res.send(deletePostById)
    }catch(err){
        res.send({message:err})
    }
})

module.exports = router