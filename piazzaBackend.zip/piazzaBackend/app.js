const express = require('express')
const app = express()

const mongoose =require('mongoose')
const bodyParser = require('body-parser')
require('dotenv/config')

app.use(bodyParser.json())

const postsRoute = require('./routes/posts')
const authRoute = require('./routes/auth')

app.use('/posts',postsRoute)
app.use('/user',authRoute)

app.get('/', (req,res) =>{
    res.send('Homepage')
})

// mongoose.connect(process.env.DB_CONNECTOR, ()=>{
//    console.log('DB is now connected!')
//})
const connectDB = async () => {
    try {
        await mongoose.connect(process.env.DB_CONNECTOR, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        })
        console.log('DB is now connected!')
    } catch (error) {
        console.error('Error connecting to MongoDB:', error)
        process.exit(1) // Exit process if connection fails
    }
}

connectDB()

app.listen(3000, ()=>{
    console.log('Server is up and running...')
})